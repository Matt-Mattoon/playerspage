from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import app
from flask import render_template,redirect,session,request,flash
from flask_app.models import models_user
from flask_app.models.models_user import User
from flask_app.controllers import controllers_users
from flask_app.models.models_workout import Workout

@app.route('/create')
def createchar():
    return render_template('addwkout.html')
    
@app.route('/create/new' , methods=['post'])
def get_better():
    data = {'name':request.form['name'],
            'type':request.form['type'],
            'difficulty':request.form['difficulty'],
            'user_id':request.form['user_id']
            }
    #defining data above so it knows what to look for when we say data below
    Workout.create(data)
    Workout.upgrade()
    #calling the function of create that we made in the attribute class
    return redirect (f'/workout/{request.form["user_id"]}')


@app.route('/workout/<int:id>')
def showcplrs(id):
    data = {'id':id}
    workout = Workout.get_one(data)
    return render_template('showcplr.html' ,  workout = workout)