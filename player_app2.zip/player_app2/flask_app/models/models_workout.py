db = 'atheletes'
from flask_app.config.mysqlconnection import connectToMySQL
# from tqdm import tqdm

class Workout:
    def __init__(self , data):
        self.id = data['id']
        self.name = data['name']
        self.type = data['type']
        self.difficulty = data['difficulty']
        self.user_id = data['user_id']
        
        
        
    @classmethod
    def create(cls,data):
        query = 'insert into workouts (name , type , difficulty , user_id) values ( %(name)s , %(type)s , %(difficulty)s , %(user_id)s )'
        return connectToMySQL(db).query_db(query ,  data)
    
    @classmethod
    def get_one(cls , data):
        query = """select * from users where id = %(id)s
        """
        results = connectToMySQL(db).query_db(query ,  data)
        attributes = []
        for attribute in results:
            attributes.append(attribute)
        return attributes
    
    def upgrade():
        for i in tqdm(range(0,100,10)):
            print (i)
    

        
        
        
    